"use strict";
exports.id = 5607;
exports.ids = [5607];
exports.modules = {

/***/ 5607:
/***/ ((module) => {

module.exports = JSON.parse('[{"id":1,"title":"How to use solid color combine with simple furnitures.","image":"/img/blog/b1.jpg","tags":["WordPress","Themeforest","Vie"],"date":{"day":"07","month":"August"}},{"id":2,"title":"How to use solid color combine with simple furnitures.","image":"/img/blog/b2.jpg","tags":["WordPress"],"date":{"day":"07","month":"August"}},{"id":3,"title":"How to use solid color combine with simple furnitures.","image":"/img/blog/b3.jpg","tags":["WordPress","Themeforest","Vie"],"date":{"day":"07","month":"August"}},{"id":4,"title":"How to use solid color combine with simple furnitures.","image":"/img/blog/b4.jpg","tags":["WordPress","Themeforest","Vie"],"date":{"day":"07","month":"August"}},{"id":5,"title":"How to use solid color combine with simple furnitures.","image":"/img/blog/b2.jpg","tags":["WordPress"],"date":{"day":"07","month":"August"}},{"id":6,"title":"How to use solid color combine with simple furnitures.","image":"/img/blog/b3.jpg","tags":["WordPress","Themeforest","Vie"],"date":{"day":"07","month":"August"}}]');

/***/ })

};
;