import React from "react";
import Homepage4 from "./homepage/home4-dark";


const Home = () => {
  return (
    <>
      
      <Homepage4 />
      
    </>
  );
};

export default Home;
